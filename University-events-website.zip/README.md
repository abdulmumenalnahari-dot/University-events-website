# CampusConnect JS (React + CRA, .js only)
- All React files use `.js` extension (no .jsx).
- Start: `npm install && npm start`
- Build: `npm run build`