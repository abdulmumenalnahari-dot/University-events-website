function Register(){
    return(<>
    <h1>
        hello on register bage
    </h1>
    
    </>)
    ;
}
export default Register;